from langchain.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import PyPDFLoader, DirectoryLoader, CSVLoader
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.agents import create_csv_agent

# Load PDF file from data path
loader = DirectoryLoader('data/',
                         glob="*.pdf",
                         loader_cls=PyPDFLoader, use_multithreading=True, show_progress=True)
documents = loader.load()

csv_loader_kwargs={'encoding': 'utf-8'}
loader_csv = DirectoryLoader('data/',
                         glob="*.csv",
                         loader_cls=CSVLoader, loader_kwargs=csv_loader_kwargs, use_multithreading=True, show_progress=True)

documents_csv = loader_csv.load()


# Split text from PDF into chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=500,
                                               chunk_overlap=50)
texts = text_splitter.split_documents(documents)

texts_csv = text_splitter.split_documents(documents_csv)

# Load embeddings model
embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2',
                                   model_kwargs={'device': 'cuda'})

# Build and persist FAISS vector store
vectorstore = FAISS.from_documents(texts, embeddings)
vectorstore_csv = FAISS.from_documents(texts_csv, embeddings)

vectorstore.save_local('vectorstore/db_faiss')
vectorstore_csv.save_local('vectorstore/db_faiss')
print("Ingestion Complete")
