from langchain import PromptTemplate
from langchain.chains import RetrievalQA, ConversationalRetrievalChain  
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from prompts import *
from llm import build_llm

# Wrap prompt template in a PromptTemplate object
def set_qa_prompt():
    prompt = PromptTemplate(template=qa_template,
                            input_variables=['context', 'question'])
    return prompt


# Build RetrievalQA object
def build_retrieval_qa(llm, prompt, vectordb):
    dbqa = RetrievalQA.from_chain_type(llm=llm,
                                       chain_type='stuff',
                                       retriever=vectordb.as_retriever(search_kwargs={'k':1}),
                                       return_source_documents=True,
                                       chain_type_kwargs={'prompt': prompt})
    #dbqa = ConversationalRetrievalChain.from_llm(llm=llm,
    #                                   chain_type='stuff',
    #                                   retriever=vectordb.as_retriever(search_kwargs={'k':1}),
    #                                   return_source_documents=True,
    #                                   combine_docs_chain_kwargs={"prompt": prompt})
    return dbqa


def load_vectorstore():
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2",
                                       model_kwargs={'device': 'cuda'})
    vectordb = FAISS.load_local('vectorstore/db_faiss', embeddings)
    return vectordb

# Instantiate QA object
def setup_dbqa():

    #vectordb = load_vectorstore()
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2",
                                       model_kwargs={'device': 'cuda'})
    vectordb = FAISS.load_local('vectorstore/db_faiss', embeddings)
    qa_prompt = set_qa_prompt()
    llm = build_llm()
    dbqa = build_retrieval_qa(llm, qa_prompt, vectordb)

    return dbqa
