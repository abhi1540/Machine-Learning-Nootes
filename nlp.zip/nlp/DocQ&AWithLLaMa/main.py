﻿import argparse
import timeit
import streamlit as st
from streamlit_chat import message
from utils import *

if __name__ == "__main__":

    #st.title('Secret ChatBot')
    ##Creating the chatbot interface
    #st.title("Chat wtih your private Data")

    #print(st.session_state)


    #def conversational_chat(query):
    #    dbqa = setup_dbqa()
    #    result = dbqa({"question": query, "chat_history": st.session_state['history']})
    #    st.session_state['history'].append((query, result["answer"]))
        
    #    return result["answer"]

    ## Storing the chat
    #if 'generated' not in st.session_state:
    #    st.session_state['generated'] = []

    #if 'past' not in st.session_state:
    #    st.session_state['past'] = []

    #if 'history' not in st.session_state:
    #    st.session_state['history'] = []



    ##container for the chat history
    #response_container = st.container()
    ##container for the user's text input
    #container = st.container()

    #with container:
    #    with st.form(key='my_form', clear_on_submit=True):
            
    #        user_input = st.text_input("Enter some text 👇", placeholder="This is a placeholder", key='input')
    #        submit_button = st.form_submit_button(label='Send')
            
    #    if submit_button and user_input:
    #        output = conversational_chat(user_input)
            
    #        st.session_state['past'].append(user_input)
    #        st.session_state['generated'].append(output)

    #if st.session_state['generated']:
    #    with response_container:
    #        for i in range(len(st.session_state['generated'])):
    #            message(st.session_state["past"][i], is_user=True, key=str(i) + '_user', avatar_style="big-smile")
    #            message(st.session_state["generated"][i], key=str(i), avatar_style="thumbs")


    #def generate_response(user_query):
    #    dbqa = setup_dbqa()
    #    response = dbqa({'query': user_query})
    #    print(response)
    #    return response['result'], response['source_documents']


       
    #def get_text():
    #    text_input = st.text_input(
    #    "Enter some text 👇",
    #    "This is a placeholder",
    #    key="input"
    #    )

        #if text_input:
        #    st.write("You entered: ", text_input)
        #input_text = st.text_input("You: ","Ask Question From your Document?", key="input")
    #    return text_input
    #user_input = get_text()

    #if user_input:
    #    output, source_doc = generate_response(user_input)
    #    # store the output 
    #    st.session_state.past.append(user_input)
    #    st.session_state.generated.append(output)
    
    #if st.session_state['generated']:
    #    for i in range(len(st.session_state['generated'])-1, -1, -1):
    #        message(st.session_state["generated"][i], key=str(i))
    #        message(st.session_state['past'][i], is_user=True, key=str(i) + '_user')



    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=str)
    args = parser.parse_args()
    start = timeit.default_timer() # Start timer

    # Setup QA object
    dbqa = setup_dbqa()
    
    # Parse input from argparse into QA object
    response = dbqa({'query': args.input})
    end = timeit.default_timer() # End timer

    # Print document QA response
    print(f'\nAnswer: {response["result"]}')
    print('='*50) # Formatting separator

    # Process source documents for better display
    source_docs = response['source_documents']
    for i, doc in enumerate(source_docs):
        print(f'\nSource Document {i+1}\n')
        print(f'Source Text: {doc.page_content}')
        print(f'Document Name: {doc.metadata["source"]}')
        print(f'Page Number: {doc.metadata["page"]}\n')
        print('='* 50) # Formatting separator
        
    # Display time taken for CPU inference
    print(f"Time to retrieve response: {end - start}")
