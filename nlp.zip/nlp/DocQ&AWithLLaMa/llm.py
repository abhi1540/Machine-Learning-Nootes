from langchain.llms import CTransformers


# Local CTransformers wrapper for Llama-2-7B-Chat
def build_llm():
    llm = CTransformers(model='models/llama-2-13b-chat.ggmlv3.q4_1.bin', # Location of downloaded GGML model
                    model_type='llama', # Model type Llama
                    config={'max_new_tokens': 512,
                            'temperature': 0.01,
                            'top_k': 10})
    return llm


